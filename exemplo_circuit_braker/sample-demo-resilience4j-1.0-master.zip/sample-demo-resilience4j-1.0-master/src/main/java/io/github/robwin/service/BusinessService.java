package io.github.robwin.service;


public interface BusinessService {
    String failure();

    String success();

    String ignore();

    String failureWithFallback();
}
