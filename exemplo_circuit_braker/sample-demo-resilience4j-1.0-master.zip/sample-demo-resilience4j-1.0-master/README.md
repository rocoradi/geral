# Spring Boot 2 demo com Resilience4j

Esta projeto mostra como usar a biblioteca de tolerância a falhas [Resilience4j](https://github.com/resilience4j/resilience4j) em uma aplicação Spring Boot 2.

Todo o funcionamento está descrito no artigo: https://www.linkedin.com/pulse/resili%25C3%25AAncia-para-microsservi%25C3%25A7os-java-circuit-breaker-silvio-buss.

## Requisitos para métricas (OPCIONAL)
[Docker](https://docs.docker.com/install/) e [Docker Compose](https://docs.docker.com/compose/install/) instalados.



